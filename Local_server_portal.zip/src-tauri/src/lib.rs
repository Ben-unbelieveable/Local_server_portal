pub mod commands;
pub mod models;
pub mod services;

use services::resource_monitor::ResourceMonitor;
use services::service_manager::AppState;
use std::sync::Arc;
use tauri::Emitter;
use tauri::Listener;
use tauri::Manager;
use tokio::sync::Mutex;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_process::init())
        .setup(|app| {
            let app_handle = app.handle().clone();

            // 初始化应用状态
            let state = AppState::new(app_handle.clone())
                .expect("无法初始化应用状态");

            let state = Arc::new(state);
            let manager = Arc::clone(&state.manager);

            // 启动资源监控定时器
            let app_handle_monitor = app_handle.clone();
            let manager_monitor = Arc::clone(&manager);
            tokio::spawn(async move {
                let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(2));
                loop {
                    interval.tick().await;

                    // 采集系统资源
                    let sys_res = ResourceMonitor::get_system_resources();

                    // 采集服务资源
                    let mut svc_resources = Vec::new();
                    {
                        let mut mgr = manager_monitor.lock().await;
                        let services = mgr.get_services();
                        for service in services {
                            if let Some(pid) = service.pid {
                                let res = ResourceMonitor::get_process_resource(
                                    &service.config.id,
                                    pid,
                                    service.uptime_secs,
                                );
                                mgr.update_resource(&service.config.id, res.cpu_percent, res.memory_mb);
                                svc_resources.push(res);
                            }
                        }
                        // 检测异常退出
                        mgr.check_process_alive();
                    }

                    // 推送资源更新事件
                    let _ = app_handle_monitor.emit(
                        "resource-update",
                        crate::models::ResourceUpdateEvent {
                            system: sys_res,
                            services: svc_resources,
                        },
                    );
                }
            });

            // 处理进程启动事件
            let app_handle1 = app_handle.clone();
            let manager1 = Arc::clone(&manager);
            app_handle.listen("service-process-started", move |event: tauri::Event| {
                if let Ok(data) = serde_json::from_str::<serde_json::Value>(event.payload()) {
                    let service_id = data["service_id"].as_str().unwrap_or("").to_string();
                    let pid = data["pid"].as_u64().unwrap_or(0) as u32;
                    let mgr = manager1.clone();
                    tokio::spawn(async move {
                        let mut m = mgr.lock().await;
                        m.on_process_started(&service_id, pid);
                    });
                }
            });

            // 处理进程停止事件
            let manager2 = Arc::clone(&manager);
            app_handle.listen("service-process-stopped", move |event: tauri::Event| {
                if let Ok(data) = serde_json::from_str::<serde_json::Value>(event.payload()) {
                    let service_id = data["service_id"].as_str().unwrap_or("").to_string();
                    let mgr = manager2.clone();
                    tokio::spawn(async move {
                        let mut m = mgr.lock().await;
                        m.on_process_stopped(&service_id);
                    });
                }
            });

            // 处理进程错误事件
            let app_handle3 = app_handle.clone();
            let manager3 = Arc::clone(&manager);
            app_handle.listen("service-process-error", move |event: tauri::Event| {
                if let Ok(data) = serde_json::from_str::<serde_json::Value>(event.payload()) {
                    let service_id = data["service_id"].as_str().unwrap_or("").to_string();
                    let error_msg = data["error"].as_str().unwrap_or("未知错误").to_string();
                    let mgr = manager3.clone();
                    let handle = app_handle3.clone();
                    tokio::spawn(async move {
                        {
                            let mut m = mgr.lock().await;
                            m.on_process_error(&service_id, &error_msg);
                        }
                        // 发送系统通知
                        let _ = handle.emit("show-notification", serde_json::json!({
                            "title": "服务异常",
                            "body": format!("服务异常退出: {}", error_msg),
                        }));
                    });
                }
            });

            // 管理 AppState
            app.manage(state);

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::get_services,
            commands::add_service,
            commands::update_service,
            commands::remove_service,
            commands::start_service,
            commands::stop_service,
            commands::restart_service,
            commands::batch_start,
            commands::batch_stop,
            commands::get_system_resources,
            commands::get_service_resources,
            commands::get_recent_logs,
            commands::search_logs,
            commands::get_history_logs,
            commands::get_config_raw,
            commands::save_config_raw,
            commands::validate_config,
            commands::handle_process_started,
            commands::handle_process_stopped,
            commands::handle_process_error,
            commands::shutdown_all_services,
        ])
        .run(tauri::generate_context!())
        .expect("启动应用失败");
}

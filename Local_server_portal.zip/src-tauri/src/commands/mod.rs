use crate::models::{
    BatchResult, LogEntry, ServiceConfig, ServiceResource, ServiceRuntime, SystemResource,
};
use crate::services::config_manager;
use crate::services::resource_monitor::ResourceMonitor;
use crate::services::service_manager::AppState;
use tauri::State;

// ==================== 服务管理 Commands ====================

#[tauri::command]
pub async fn get_services(state: State<'_, AppState>) -> Result<Vec<ServiceRuntime>, String> {
    let manager = state.manager.lock().await;
    Ok(manager.get_services())
}

#[tauri::command]
pub async fn add_service(
    state: State<'_, AppState>,
    config: ServiceConfig,
) -> Result<ServiceRuntime, String> {
    let mut manager = state.manager.lock().await;
    manager.add_service(config)
}

#[tauri::command]
pub async fn update_service(
    state: State<'_, AppState>,
    id: String,
    config: ServiceConfig,
) -> Result<ServiceRuntime, String> {
    let mut manager = state.manager.lock().await;
    manager.update_service(&id, config)
}

#[tauri::command]
pub async fn remove_service(
    state: State<'_, AppState>,
    id: String,
    stop_first: bool,
) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.remove_service(&id, stop_first)
}

#[tauri::command]
pub async fn start_service(state: State<'_, AppState>, id: String) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.start_service(&id).await
}

#[tauri::command]
pub async fn stop_service(state: State<'_, AppState>, id: String) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.stop_service(&id).await
}

#[tauri::command]
pub async fn restart_service(state: State<'_, AppState>, id: String) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.restart_service(&id).await
}

#[tauri::command]
pub async fn batch_start(
    state: State<'_, AppState>,
    ids: Vec<String>,
) -> Result<Vec<BatchResult>, String> {
    let mut manager = state.manager.lock().await;
    Ok(manager.batch_start(&ids).await)
}

#[tauri::command]
pub async fn batch_stop(
    state: State<'_, AppState>,
    ids: Vec<String>,
) -> Result<Vec<BatchResult>, String> {
    let mut manager = state.manager.lock().await;
    Ok(manager.batch_stop(&ids).await)
}

// ==================== 资源监控 Commands ====================

#[tauri::command]
pub async fn get_system_resources() -> Result<SystemResource, String> {
    Ok(ResourceMonitor::get_system_resources())
}

#[tauri::command]
pub async fn get_service_resources(
    state: State<'_, AppState>,
) -> Result<Vec<ServiceResource>, String> {
    let manager = state.manager.lock().await;
    let services = manager.get_services();
    let mut resources = Vec::new();

    for service in services {
        if let Some(pid) = service.pid {
            let res = ResourceMonitor::get_process_resource(&service.config.id, pid, service.uptime_secs);
            resources.push(res);
        }
    }

    Ok(resources)
}

// ==================== 日志 Commands ====================

#[tauri::command]
pub async fn get_recent_logs(
    state: State<'_, AppState>,
    service_id: String,
    count: u32,
) -> Result<Vec<LogEntry>, String> {
    let manager = state.manager.lock().await;
    let log_mgr = manager.log_manager();
    Ok(log_mgr.get_recent(&service_id, count as usize))
}

#[tauri::command]
pub async fn search_logs(
    state: State<'_, AppState>,
    service_id: String,
    keyword: String,
) -> Result<Vec<LogEntry>, String> {
    let manager = state.manager.lock().await;
    let log_mgr = manager.log_manager();
    Ok(log_mgr.search(&service_id, &keyword))
}

#[tauri::command]
pub async fn get_history_logs(
    state: State<'_, AppState>,
    service_id: String,
    date: String,
) -> Result<Vec<LogEntry>, String> {
    let manager = state.manager.lock().await;
    let log_mgr = manager.log_manager();
    Ok(log_mgr.get_history(&service_id, &date))
}

// ==================== 配置 Commands ====================

#[tauri::command]
pub async fn get_config_raw() -> Result<String, String> {
    let path = config_manager::config_path();
    if path.exists() {
        std::fs::read_to_string(&path).map_err(|e| format!("读取配置文件失败: {}", e))
    } else {
        Ok(String::new())
    }
}

#[tauri::command]
pub async fn save_config_raw(content: String) -> Result<(), String> {
    // 先校验格式
    config_manager::validate_yaml(&content)?;
    std::fs::write(config_manager::config_path(), &content)
        .map_err(|e| format!("保存配置文件失败: {}", e))
}

#[tauri::command]
pub async fn validate_config(content: String) -> Result<String, String> {
    match config_manager::validate_yaml(&content) {
        Ok(_) => Ok("ok".to_string()),
        Err(e) => Err(e),
    }
}

// ==================== 内部事件处理 Commands ====================

#[tauri::command]
pub async fn handle_process_started(
    state: State<'_, AppState>,
    service_id: String,
    pid: u32,
) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.on_process_started(&service_id, pid);
    Ok(())
}

#[tauri::command]
pub async fn handle_process_stopped(
    state: State<'_, AppState>,
    service_id: String,
) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.on_process_stopped(&service_id);
    Ok(())
}

#[tauri::command]
pub async fn handle_process_error(
    state: State<'_, AppState>,
    service_id: String,
    error: String,
) -> Result<(), String> {
    let mut manager = state.manager.lock().await;
    manager.on_process_error(&service_id, &error);
    Ok(())
}

#[tauri::command]
pub async fn shutdown_all_services(state: State<'_, AppState>) -> Result<Vec<BatchResult>, String> {
    let mut manager = state.manager.lock().await;
    Ok(manager.shutdown_all().await)
}

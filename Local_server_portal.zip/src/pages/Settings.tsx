import { useState, useEffect, useRef } from "react";
import { Button, App, Space, Card, Typography, Alert } from "antd";
import { SaveOutlined, ReloadOutlined } from "@ant-design/icons";
import { EditorView, basicSetup } from "codemirror";
import { yaml } from "@codemirror/lang-yaml";
import { oneDark } from "@codemirror/theme-one-dark";
import { api } from "../api";

export default function Settings() {
  const { message } = App.useApp();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);

  useEffect(() => {
    if (!editorRef.current) return;

    const loadConfig = async () => {
      try {
        const data = await api.getConfigRaw();
        const view = new EditorView({
          doc: data || exampleConfig,
          extensions: [basicSetup, yaml(), oneDark],
          parent: editorRef.current!,
        });
        viewRef.current = view;
      } catch (e) {
        message.error(String(e));
      }
    };

    loadConfig();

    return () => {
      viewRef.current?.destroy();
    };
  }, []);

  const handleSave = async () => {
    if (!viewRef.current) return;
    const content = viewRef.current.state.doc.toString();
    setSaving(true);
    setError(null);

    try {
      // 先校验
      await api.validateConfig(content);
      await api.saveConfigRaw(content);
      message.success("配置已保存，服务列表已更新");
    } catch (e) {
      const errMsg = String(e);
      setError(errMsg);
      message.error("保存失败：" + errMsg);
    }
    setSaving(false);
  };

  const handleReload = async () => {
    try {
      const data = await api.getConfigRaw();
      if (viewRef.current) {
        viewRef.current.dispatch({
          changes: {
            from: 0,
            to: viewRef.current.state.doc.length,
            insert: data || exampleConfig,
          },
        });
      }
      message.success("已重新加载");
    } catch (e) {
      message.error(String(e));
    }
  };

  return (
    <div>
      <Card
        title="配置文件编辑"
        extra={
          <Space>
            <Button icon={<ReloadOutlined />} onClick={handleReload}>
              重新加载
            </Button>
            <Button
              type="primary"
              icon={<SaveOutlined />}
              onClick={handleSave}
              loading={saving}
            >
              保存配置
            </Button>
          </Space>
        }
      >
        <Typography.Paragraph type="secondary" style={{ marginBottom: 12 }}>
          直接编辑 YAML 配置文件，支持语法高亮。修改后点击「保存配置」即可生效，正在运行的服务不受影响。
        </Typography.Paragraph>

        {error && (
          <Alert
            type="error"
            message="保存失败"
            description={error}
            showIcon
            closable
            style={{ marginBottom: 12 }}
            onClose={() => setError(null)}
          />
        )}

        <div
          ref={editorRef}
          style={{
            border: "1px solid #303030",
            borderRadius: 6,
            overflow: "hidden",
            minHeight: 450,
          }}
        />
      </Card>
    </div>
  );
}

const exampleConfig = `# 本地服务管理平台 - 服务配置文件
# 编辑后点击「保存配置」即可生效

services:
  - id: antibody_annotation
    name: Antibody Annotation
    command: bash /Users/liubo/github/antibody_annotation/deploy.sh
    url: http://localhost:3000
    work_dir: /Users/liubo/github/antibody_annotation
    env:
      PORT: "3000"
    group: Web服务
    description: 抗体标注 Web 服务
    stop_timeout: 10

  - id: ollama
    name: Ollama AI
    command: ollama serve
    group: AI模型
    description: Ollama 大模型推理服务（高资源消耗）
    stop_timeout: 15
`;

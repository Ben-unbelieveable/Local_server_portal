import { Card, Col, Row, Statistic, Table, Tag, Progress, Empty, Button, Typography, Tooltip } from "antd";
import {
  PlayCircleOutlined,
  PauseCircleOutlined,
  WarningOutlined,
  CheckCircleOutlined,
  PlusOutlined,
  ExportOutlined,
} from "@ant-design/icons";
import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api, isTauriEnv } from "../api";
import { useTauriEvent } from "../hooks/useTauriEvent";
import type {
  ServiceRuntime,
  SystemResource,
  ResourceUpdateEvent,
  StatusChangeEvent,
  ServiceResource,
} from "../types";

export default function Dashboard() {
  const navigate = useNavigate();
  const [services, setServices] = useState<ServiceRuntime[]>([]);
  const [resource, setResource] = useState<SystemResource | null>(null);
  const [svcResources, setSvcResources] = useState<ServiceResource[]>([]);

  const fetchData = useCallback(async () => {
    try {
      const [svc, res] = await Promise.all([
        api.getServices(),
        api.getSystemResources(),
      ]);
      setServices(svc);
      setResource(res);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useTauriEvent<ResourceUpdateEvent>("resource-update", (payload) => {
    setResource(payload.system);
    setSvcResources(payload.services);
  });

  useTauriEvent<StatusChangeEvent>("service-status-changed", () => {
    fetchData();
  });

  const runningCount = services.filter((s) => s.status === "running").length;
  const stoppedCount = services.filter((s) => s.status === "stopped").length;
  const errorCount = services.filter(
    (s) => s.status === "failed" || s.status === "error"
  ).length;

  // Top 5 by memory
  const top5 = [...svcResources]
    .sort((a, b) => b.memory_mb - a.memory_mb)
    .slice(0, 5);

  // 打开服务 URL
  const openServiceUrl = (url: string) => {
    if (isTauriEnv) {
      // Tauri 环境：用 shell open 打开浏览器
      import("@tauri-apps/plugin-shell").then(({ open }) => {
        open(url);
      }).catch(() => {
        window.open(url, "_blank");
      });
    } else {
      window.open(url, "_blank");
    }
  };

  const statusMap: Record<string, { color: string; icon: React.ReactNode; text: string }> = {
    running: { color: "green", icon: <CheckCircleOutlined />, text: "运行中" },
    stopped: { color: "default", icon: <PauseCircleOutlined />, text: "已停止" },
    starting: { color: "orange", icon: <PlayCircleOutlined spin />, text: "启动中" },
    stopping: { color: "orange", icon: <PauseCircleOutlined spin />, text: "停止中" },
    failed: { color: "red", icon: <WarningOutlined />, text: "启动失败" },
    error: { color: "red", icon: <WarningOutlined />, text: "异常" },
  };

  const columns = [
    {
      title: "服务名称",
      dataIndex: ["config", "name"],
      key: "name",
      render: (name: string, record: ServiceRuntime) => (
        <a onClick={() => navigate(`/logs/${record.config.id}`)}>{name}</a>
      ),
    },
    {
      title: "状态",
      dataIndex: "status",
      key: "status",
      width: 100,
      render: (status: string) => {
        const s = statusMap[status] || statusMap.stopped;
        return <Tag color={s.color}>{s.text}</Tag>;
      },
    },
    {
      title: "CPU",
      key: "cpu",
      width: 90,
      render: (_: unknown, record: ServiceRuntime) => {
        if (record.status !== "running") return "-";
        const r = svcResources.find((x) => x.service_id === record.config.id);
        return (
          <Progress
            percent={r ? Math.round(r.cpu_percent) : 0}
            size="small"
            strokeColor={(r?.cpu_percent ?? 0) > 80 ? "#ff4d4f" : "#52c41a"}
          />
        );
      },
    },
    {
      title: "内存",
      key: "memory",
      width: 90,
      render: (_: unknown, record: ServiceRuntime) => {
        if (record.status !== "running") return "-";
        const r = svcResources.find((x) => x.service_id === record.config.id);
        return r ? `${r.memory_mb.toFixed(0)} MB` : "-";
      },
    },
    {
      title: "��行时长",
      key: "uptime",
      width: 90,
      render: (_: unknown, record: ServiceRuntime) => {
        if (record.status !== "running") return "-";
        const h = Math.floor(record.uptime_secs / 3600);
        const m = Math.floor((record.uptime_secs % 3600) / 60);
        const s = record.uptime_secs % 60;
        return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
      },
    },
    {
      title: "操作",
      key: "action",
      width: 80,
      render: (_: unknown, record: ServiceRuntime) => {
        if (record.status === "running" && record.config.url) {
          return (
            <Tooltip title={`访问 ${record.config.url}`}>
              <Button
                size="small"
                type="link"
                icon={<ExportOutlined />}
                onClick={(e) => {
                  e.stopPropagation();
                  openServiceUrl(record.config.url!);
                }}
              >
                访问
              </Button>
            </Tooltip>
          );
        }
        return "-";
      },
    },
  ];

  if (services.length === 0) {
    return (
      <Empty description="还没有服务" style={{ marginTop: 80 }}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={() => navigate("/services")}
        >
          添加第一个服务
        </Button>
      </Empty>
    );
  }

  return (
    <div>
      <Row gutter={[16, 16]}>
        <Col span={6}>
          <Card>
            <Statistic
              title="CPU 使用率"
              value={resource ? Math.round(resource.cpu_percent) : 0}
              suffix="%"
              valueStyle={{
                color: (resource?.cpu_percent ?? 0) > 80 ? "#ff4d4f" : "#52c41a",
              }}
            />
            <Progress
              percent={resource ? Math.round(resource.cpu_percent) : 0}
              strokeColor={(resource?.cpu_percent ?? 0) > 80 ? "#ff4d4f" : "#52c41a"}
              showInfo={false}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="内存使用率"
              value={resource ? Math.round(resource.memory_percent) : 0}
              suffix="%"
              valueStyle={{
                color: (resource?.memory_percent ?? 0) > 85 ? "#ff4d4f" : "#52c41a",
              }}
            />
            <Progress
              percent={resource ? Math.round(resource.memory_percent) : 0}
              strokeColor={(resource?.memory_percent ?? 0) > 85 ? "#ff4d4f" : "#52c41a"}
              showInfo={false}
            />
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              {resource?.memory_used_gb.toFixed(1)} / {resource?.memory_total_gb.toFixed(0)} GB
            </Typography.Text>
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title={resource?.gpu_name ? `GPU (${resource.gpu_name})` : "GPU"}
              value={resource?.gpu_percent ? Math.round(resource.gpu_percent) : "-"}
              suffix={resource?.gpu_percent != null ? "%" : ""}
              valueStyle={{
                color: (resource?.gpu_percent ?? 0) > 80 ? "#ff4d4f" : "#52c41a",
              }}
            />
            {resource?.gpu_percent != null ? (
              <>
                <Progress
                  percent={Math.round(resource.gpu_percent)}
                  strokeColor={(resource.gpu_percent ?? 0) > 80 ? "#ff4d4f" : "#52c41a"}
                  showInfo={false}
                />
                {resource.gpu_memory_used_mb != null && resource.gpu_memory_total_mb != null && (
                  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                    VRAM: {resource.gpu_memory_used_mb.toFixed(0)} / {resource.gpu_memory_total_mb.toFixed(0)} MB
                  </Typography.Text>
                )}
              </>
            ) : (
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                {resource?.gpu_name ? "利用率不可用" : "未检测到 GPU"}
              </Typography.Text>
            )}
          </Card>
        </Col>
        <Col span={6}>
          <Row gutter={[16, 8]}>
            <Col span={12}>
              <Card size="small">
                <Statistic title="运行中" value={runningCount} valueStyle={{ color: "#52c41a", fontSize: 20 }} />
              </Card>
            </Col>
            <Col span={12}>
              <Card size="small">
                <Statistic title="已停止" value={stoppedCount} valueStyle={{ fontSize: 20 }} />
              </Card>
            </Col>
            <Col span={24}>
              <Card size="small">
                <Statistic
                  title="异常"
                  value={errorCount}
                  valueStyle={{ color: errorCount > 0 ? "#ff4d4f" : undefined, fontSize: 20 }}
                />
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col span={16}>
          <Card title="服务列表">
            <Table
              dataSource={services}
              columns={columns}
              rowKey={(r) => r.config.id}
              pagination={false}
              size="small"
              onRow={(record) => ({
                style: { cursor: "pointer" },
                onClick: () => navigate(`/services?highlight=${record.config.id}`),
              })}
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card title="内存占用 Top 5">
            {top5.length === 0 ? (
              <Empty description="暂无运行中的服务" image={Empty.PRESENTED_IMAGE_SIMPLE} />
            ) : (
              top5.map((item, index) => {
                const svc = services.find((s) => s.config.id === item.service_id);
                return (
                  <div
                    key={item.service_id}
                    style={{ display: "flex", alignItems: "center", marginBottom: 8, gap: 8 }}
                  >
                    <Tag color={index < 3 ? "gold" : "default"}>{index + 1}</Tag>
                    <span style={{ flex: 1 }}>{svc?.config.name || item.service_id}</span>
                    <Progress
                      percent={Math.round(item.memory_mb / (resource?.memory_total_gb ?? 1) / 1024 * 100)}
                      size="small"
                      style={{ width: 100 }}
                      showInfo={false}
                    />
                    <Typography.Text type="secondary" style={{ fontSize: 12, width: 60 }}>
                      {item.memory_mb.toFixed(0)} MB
                    </Typography.Text>
                  </div>
                );
              })
            )}
          </Card>
        </Col>
      </Row>
    </div>
  );
}

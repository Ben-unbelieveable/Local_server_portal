import { useEffect, useRef } from "react";
import type { ServiceRuntime, SystemResource, StatusChangeEvent, ResourceUpdateEvent } from "../types";
import { api } from "../api";

const isTauri = typeof window !== "undefined" && "__TAURI__" in window;

export function useSystemTray() {
  const trayRef = useRef<{ setMenu: (m: unknown) => Promise<void> } | null>(null);
  const servicesRef = useRef<ServiceRuntime[]>([]);
  const resourceRef = useRef<SystemResource | null>(null);

  useEffect(() => {
    if (!isTauri) return;
    let cancelled = false;

    const init = async () => {
      try {
        // 动态导入 Tauri API（避免非 Tauri 环境报错）
        const [{ TrayIcon }, { Menu }, { defaultWindowIcon }] = await Promise.all([
          import("@tauri-apps/api/tray"),
          import("@tauri-apps/api/menu"),
          import("@tauri-apps/api/app"),
        ]);

        const icon = (await defaultWindowIcon()) ?? undefined;

        const menu = await Menu.new({
          items: [{ id: "loading", text: "加载中...", enabled: false }],
        });

        const tray = (await TrayIcon.new({
          icon: icon as unknown as string,
          menu,
          menuOnLeftClick: true,
          tooltip: "本地服务管理平台",
          action: (event: { type: string }) => {
            if (event.type === "DoubleClick") {
              import("@tauri-apps/api/window").then(async ({ getCurrentWindow }) => {
                const w = await getCurrentWindow();
                await w.show();
                await w.setFocus();
              });
            }
          },
        })) as unknown as { setMenu: (m: unknown) => Promise<void> };

        if (cancelled) return;
        trayRef.current = tray;

        // 监听事件
        const { listen } = await import("@tauri-apps/api/event");
        listen<StatusChangeEvent>("service-status-changed", async () => {
          const svc = await api.getServices();
          servicesRef.current = svc;
          await updateTrayMenu(trayRef.current, svc, resourceRef.current);
        });

        listen<ResourceUpdateEvent>("resource-update", async (event) => {
          resourceRef.current = event.payload.system;
          await updateTrayMenu(trayRef.current, servicesRef.current, event.payload.system);
        });

        // 初始数据
        const [svc, res] = await Promise.all([api.getServices(), api.getSystemResources()]);
        servicesRef.current = svc;
        resourceRef.current = res;
        await updateTrayMenu(trayRef.current, svc, res);
      } catch (e) {
        console.error("Tray init failed:", e);
      }
    };

    init();
    return () => { cancelled = true; };
  }, []);
}

async function updateTrayMenu(
  tray: { setMenu: (m: unknown) => Promise<void> } | null,
  services: ServiceRuntime[],
  resource: SystemResource | null
) {
  if (!tray) return;

  const { Menu } = await import("@tauri-apps/api/menu");

  const items: Array<{
    id: string;
    text: string;
    enabled?: boolean;
    action?: () => void;
  }> = [];

  // 资源摘要
  if (resource) {
    items.push({
      id: "resource-header",
      text: `💻 CPU: ${Math.round(resource.cpu_percent)}%  |  内存: ${resource.memory_used_gb.toFixed(1)}/${resource.memory_total_gb.toFixed(0)} GB`,
      enabled: false,
    });

    if (resource.gpu_percent != null) {
      items.push({
        id: "gpu-header",
        text: `🎮 GPU: ${Math.round(resource.gpu_percent)}%  |  VRAM: ${(resource.gpu_memory_used_mb ?? 0).toFixed(0)}/${(resource.gpu_memory_total_mb ?? 0).toFixed(0)} MB`,
        enabled: false,
      });
    }

    items.push({ id: "sep-0", text: "──────────────", enabled: false });
  }

  // 服务列表
  if (services.length === 0) {
    items.push({ id: "no-services", text: "暂无已配置的服务", enabled: false });
  } else {
    const groups = new Map<string, ServiceRuntime[]>();
    for (const svc of services) {
      const g = svc.config.group || "默认";
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g)!.push(svc);
    }

    for (const [group, svcs] of groups) {
      items.push({ id: `group-${group}`, text: `📁 ${group}`, enabled: false });
      for (const svc of svcs) {
        const icon = svc.status === "running" ? "🟢"
          : svc.status === "error" || svc.status === "failed" ? "🔴" : "⚪";
        const extra = svc.status === "running"
          ? `  CPU:${Math.round(svc.cpu_percent)}%  MEM:${svc.memory_mb.toFixed(0)}MB`
          : "";
        items.push({
          id: `svc-${svc.config.id}`,
          text: `  ${icon} ${svc.config.name}${extra}`,
          action: async () => {
            try {
              if (svc.status === "running") {
                await api.stopService(svc.config.id);
              } else if (svc.status === "stopped" || svc.status === "failed" || svc.status === "error") {
                await api.startService(svc.config.id);
              }
            } catch { /* ignore */ }
          },
        });
      }
    }
  }

  items.push({ id: "sep-1", text: "──────────────", enabled: false });
  items.push({
    id: "open-dashboard",
    text: "📊 打开管理界面",
    action: async () => {
      const { getCurrentWindow } = await import("@tauri-apps/api/window");
      const win = await getCurrentWindow();
      await win.show();
      await win.setFocus();
    },
  });
  items.push({
    id: "start-all",
    text: "▶️ 启动全部",
    action: async () => {
      const ids = services.filter((s) => s.status !== "running").map((s) => s.config.id);
      if (ids.length > 0) await api.batchStart(ids);
    },
  });
  items.push({
    id: "stop-all",
    text: "⏹️ 停止全部",
    action: async () => {
      const ids = services.filter((s) => s.status === "running").map((s) => s.config.id);
      if (ids.length > 0) await api.batchStop(ids);
    },
  });
  items.push({ id: "sep-2", text: "──────────────", enabled: false });
  items.push({
    id: "quit",
    text: "❌ 退出",
    action: async () => {
      const ok = window.confirm("退出将停止所有正在运行的服务，是否继续？");
      if (ok) {
        await api.shutdownAll();
        const { getCurrentWindow } = await import("@tauri-apps/api/window");
        await (await getCurrentWindow()).close();
      }
    },
  });

  const newMenu = await Menu.new({ items });
  await tray.setMenu(newMenu);
}

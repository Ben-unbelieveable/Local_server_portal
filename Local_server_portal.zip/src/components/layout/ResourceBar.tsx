import { Progress, Space, Tag, Typography } from "antd";
import { useEffect, useState } from "react";
import type { SystemResource } from "../../types";
import { api } from "../../api";
import { useTauriEvent } from "../../hooks/useTauriEvent";
import type { ResourceUpdateEvent } from "../../types";

export default function ResourceBar() {
  const [resource, setResource] = useState<SystemResource | null>(null);
  const [runningCount, setRunningCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  const fetchResources = async () => {
    try {
      const [res, services] = await Promise.all([
        api.getSystemResources(),
        api.getServices(),
      ]);
      setResource(res);
      setTotalCount(services.length);
      setRunningCount(services.filter((s) => s.status === "running").length);
    } catch {
      // 忽略
    }
  };

  useEffect(() => {
    fetchResources();
    const interval = setInterval(fetchResources, 3000);
    return () => clearInterval(interval);
  }, []);

  useTauriEvent<ResourceUpdateEvent>("resource-update", (payload) => {
    setResource(payload.system);
  });

  if (!resource) return null;

  const cpuColor =
    resource.cpu_percent > 80
      ? "#ff4d4f"
      : resource.cpu_percent > 50
        ? "#faad14"
        : "#52c41a";
  const memColor =
    resource.memory_percent > 85
      ? "#ff4d4f"
      : resource.memory_percent > 60
        ? "#faad14"
        : "#52c41a";

  return (
    <div
      style={{
        height: 48,
        display: "flex",
        alignItems: "center",
        padding: "0 24px",
        borderBottom: "1px solid #f0f0f0",
        background: "inherit",
        gap: 24,
      }}
    >
      <Space size={16}>
        <Space size={4}>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            CPU
          </Typography.Text>
          <Progress
            type="circle"
            percent={Math.round(resource.cpu_percent)}
            size={24}
            strokeColor={cpuColor}
            format={(p) => `${p}%`}
            style={{ lineHeight: 1 }}
          />
        </Space>
        <Space size={4}>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            MEM
          </Typography.Text>
          <Progress
            type="circle"
            percent={Math.round(resource.memory_percent)}
            size={24}
            strokeColor={memColor}
            format={(p) => `${p}%`}
            style={{ lineHeight: 1 }}
          />
        </Space>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          {resource.memory_used_gb.toFixed(1)} /{" "}
          {resource.memory_total_gb.toFixed(0)} GB
        </Typography.Text>
        {resource.gpu_percent != null && (
          <>
            <Space size={4}>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                GPU
              </Typography.Text>
              <Progress
                type="circle"
                percent={Math.round(resource.gpu_percent)}
                size={24}
                strokeColor={(resource.gpu_percent ?? 0) > 80 ? "#ff4d4f" : "#52c41a"}
                format={(p) => `${p}%`}
                style={{ lineHeight: 1 }}
              />
            </Space>
            {resource.gpu_memory_used_mb != null && (
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                {resource.gpu_memory_used_mb.toFixed(0)} MB
              </Typography.Text>
            )}
          </>
        )}
      </Space>
      <div style={{ flex: 1 }} />
      <Tag color="green">
        运行中 {runningCount} / {totalCount}
      </Tag>
    </div>
  );
}

import { Layout, Menu, Switch, Typography } from "antd";
import {
  DashboardOutlined,
  ToolOutlined,
  FileTextOutlined,
  SettingOutlined,
  SunOutlined,
  MoonOutlined,
} from "@ant-design/icons";
import { useNavigate, useLocation } from "react-router-dom";
import type { ReactNode } from "react";
import ResourceBar from "./ResourceBar";

const { Sider, Content } = Layout;

interface Props {
  children: ReactNode;
  isDark: boolean;
  onToggleTheme: () => void;
}

const menuItems = [
  { key: "/", icon: <DashboardOutlined />, label: "仪表盘" },
  { key: "/services", icon: <ToolOutlined />, label: "服务管理" },
  { key: "/logs", icon: <FileTextOutlined />, label: "日志" },
  { key: "/settings", icon: <SettingOutlined />, label: "配置" },
];

export default function AppLayout({ children, isDark, onToggleTheme }: Props) {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Layout style={{ height: "100vh" }}>
      <Sider
        width={200}
        theme={isDark ? "dark" : "light"}
        style={{
          borderRight: "1px solid",
          borderColor: isDark ? "#303030" : "#f0f0f0",
        }}
      >
        <div
          style={{
            height: 48,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderBottom: "1px solid",
            borderColor: isDark ? "#303030" : "#f0f0f0",
          }}
        >
          <Typography.Title level={5} style={{ margin: 0 }}>
            ⚡ ServicePilot
          </Typography.Title>
        </div>
        <Menu
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={({ key }) => navigate(key)}
          style={{ borderRight: 0, marginTop: 8 }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 16,
            left: 16,
            right: 16,
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <Switch
            checkedChildren={<MoonOutlined />}
            unCheckedChildren={<SunOutlined />}
            checked={isDark}
            onChange={onToggleTheme}
            size="small"
          />
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            v0.1.0
          </Typography.Text>
        </div>
      </Sider>
      <Layout>
        <ResourceBar />
        <Content
          style={{
            padding: 24,
            overflow: "auto",
            background: isDark ? "#141414" : "#f5f5f5",
          }}
        >
          {children}
        </Content>
      </Layout>
    </Layout>
  );
}

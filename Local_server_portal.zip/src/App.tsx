import { Routes, Route } from "react-router-dom";
import { ConfigProvider, theme } from "antd";
import { useState, useEffect } from "react";
import AppLayout from "./components/layout/AppLayout";
import Dashboard from "./pages/Dashboard";
import Services from "./pages/Services";
import Logs from "./pages/Logs";
import Settings from "./pages/Settings";
import { useSystemTray } from "./hooks/useSystemTray";

export default function App() {
  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved === "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    localStorage.setItem("theme", isDark ? "dark" : "light");
  }, [isDark]);

  const toggleTheme = () => setIsDark((prev) => !prev);

  // 初始化系统托盘
  useSystemTray();

  return (
    <ConfigProvider
      theme={{
        algorithm: isDark ? theme.darkAlgorithm : theme.defaultAlgorithm,
        token: { colorPrimary: "#1677ff", borderRadius: 6 },
      }}
    >
      <AppLayout isDark={isDark} onToggleTheme={toggleTheme}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/services" element={<Services />} />
          <Route path="/logs" element={<Logs />} />
          <Route path="/logs/:serviceId" element={<Logs />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </AppLayout>
    </ConfigProvider>
  );
}
